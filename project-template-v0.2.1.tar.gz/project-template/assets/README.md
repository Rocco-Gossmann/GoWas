### Assets Directory

put your PNG files and other ressource to be imported into GoWas here.

The `make` command will automatically pick them up and convert them for you.
