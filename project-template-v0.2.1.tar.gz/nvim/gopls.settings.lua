return {
	gopls = {
		buildFlags = { "-tags=js,wasm" },
	},
}
