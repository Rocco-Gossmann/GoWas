package main

import (
	"GoWasProject/scenes"

	"github.com/rocco-gossmann/GoWas"
)

func main() {

	e := GoWas.Init(GoWas.EngineSetup{
		WindowWidth:  160, // pixels
		WindowHeight: 144, // pixels

		AutoClearPixels: true,
		AutoClearColor:  0x00333333, // 0x00 RR GG BB - color

		TileMapWidth:  22, // Tiles
		TileMapHeight: 22, // Tiles
	})

	e.Run(&scenes.StartScene)
}
