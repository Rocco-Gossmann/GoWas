package scenes

import (
	"github.com/rocco-gossmann/GoWas/core"
)

// Scene Definition
// ==============================================================================
type startScene struct {
	// Put scene specific properties definitions here
}

// Scene Initialization
// ==============================================================================
var StartScene = startScene{
	// Initialize scene specific properties here
}

// Scene Lifecycle-Hooks
// Remove which ever you don't need. (should you remove both Tick and Draw, the scene will become invalid)
// ==============================================================================

// Loading
// ------------------------------------------------------------------------------
func (me *startScene) Load(e *core.EngineState, ca *core.Canvas) {

	// Load your Ressources Here
	// (use `me` to access properties of your sceen)

}

// Ticking
// ------------------------------------------------------------------------------
func (me *startScene) Tick(e *core.EngineState) bool {

	// Run none graphics related commands here

	return true
}

// Drawing
// ------------------------------------------------------------------------------
func (me *startScene) Draw(e *core.EngineState, ca *core.Canvas) {

	// Draw to the Canvas here

}

// Unloading
// ------------------------------------------------------------------------------
func (me *startScene) Unload(e *core.EngineState) *struct{} {

	// Unload your ressources here

	// and define a followup scenen, be returning its pointer here

	return nil
}
